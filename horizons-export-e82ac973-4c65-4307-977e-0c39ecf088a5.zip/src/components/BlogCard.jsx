
import React from "react";
import { motion } from "framer-motion";
import { Calendar, User } from "lucide-react";
import { Button } from "@/components/ui/button";

const BlogCard = ({ post, onReadMore }) => {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 group"
    >
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        <img 
          src={post.image} 
          alt={post.title}
          className="w-full h-48 object-cover transform group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <div className="flex items-center gap-4 text-white/90 text-sm">
            <div className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              <span>{post.date}</span>
            </div>
            <div className="flex items-center gap-1">
              <User className="w-4 h-4" />
              <span>{post.author}</span>
            </div>
          </div>
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold text-primary mb-2 line-clamp-2">{post.title}</h3>
        <p className="text-gray-600 mb-4 line-clamp-3">{post.excerpt}</p>
        <Button
          onClick={() => onReadMore(post)}
          variant="outline"
          className="w-full border-primary text-primary hover:bg-primary hover:text-white transform transition-all duration-300 hover:scale-105"
        >
          Leer más
        </Button>
      </div>
    </motion.div>
  );
};

export default BlogCard;
