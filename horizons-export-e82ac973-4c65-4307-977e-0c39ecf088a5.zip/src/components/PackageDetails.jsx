
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CheckCircle2, MapPin, Calendar, Users, Coffee, ChevronLeft, ChevronRight, Plus, Minus, Car, Hotel as HotelIcon, CreditCard, Clock, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format, addDays } from "date-fns";
import TermsDialog from "@/components/TermsDialog";

// Rest of the imports and component code remains the same until line 260

                <div className="bg-primary/5 rounded-lg p-3 text-sm text-gray-600">
                  <p className="mb-1">• Menores de 4 años no pagan pasajes, hotel, pero no tienen beneficio de comida</p>
                  <p>• Mayores de 5 años pagan pasajes y tienen todos los beneficios completos</p>
                </div>

// Rest of the component code remains exactly the same
