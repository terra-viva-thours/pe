
import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar, User, Clock, MapPin, Camera, Tag } from "lucide-react";

const BlogPostDialog = ({ post, open, onOpenChange }) => {
  if (!post) return null;

  const images = [
    post.image,
    "https://images.unsplash.com/photo-1566073771259-6a8506099945",
    "https://images.unsplash.com/photo-1434725039720-aaad6dd32dfe",
    "https://images.unsplash.com/photo-1501785888041-af3ef285b470"
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[95vw] w-full p-0 overflow-hidden bg-white rounded-xl">
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="relative"
          >
            {/* Hero Image */}
            <div className="relative h-[60vh] overflow-hidden">
              <motion.img
                src={post.image}
                alt={post.title}
                className="w-full h-full object-cover"
                initial={{ scale: 1.1 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.6 }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="absolute bottom-0 left-0 right-0 p-8 text-white"
              >
                <h2 className="text-5xl font-bold mb-6">{post.title}</h2>
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5" />
                    <span>{post.date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <User className="w-5 h-5" />
                    <span>{post.author}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    <span>5 min lectura</span>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Content */}
            <div className="p-12 max-w-6xl mx-auto">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="prose max-w-none"
              >
                <div className="mb-12">
                  <h3 className="text-3xl font-bold mb-6">Sobre el Destino</h3>
                  <p className="text-gray-600 leading-relaxed text-lg">
                    Tarapoto, conocida como la Ciudad de las Palmeras, es un paraíso tropical ubicado en el departamento de San Martín, Perú. Con su clima cálido y húmedo, esta ciudad es el punto de partida perfecto para explorar la exuberante selva amazónica y sus maravillas naturales.
                  </p>
                </div>

                {/* Image Gallery */}
                <div className="grid grid-cols-2 gap-8 mb-12">
                  {images.map((image, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 * index }}
                      className="relative rounded-xl overflow-hidden"
                    >
                      <img
                        src={image}
                        alt={`Imagen ${index + 1}`}
                        className="w-full h-72 object-cover"
                      />
                      <div className="absolute inset-0 bg-black/20 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Camera className="w-12 h-12 text-white" />
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="mb-12">
                  <h3 className="text-3xl font-bold mb-6">Detalles del Lugar</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="flex items-start gap-4">
                      <MapPin className="w-8 h-8 text-primary mt-1" />
                      <div>
                        <h4 className="text-xl font-bold mb-3">Ubicación</h4>
                        <p className="text-gray-600 text-lg">
                          A solo 15 minutos del centro de la ciudad, rodeado de naturaleza y paz.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <Tag className="w-8 h-8 text-primary mt-1" />
                      <div>
                        <h4 className="text-xl font-bold mb-3">Características</h4>
                        <p className="text-gray-600 text-lg">
                          Clima tropical, cascadas naturales, y rica biodiversidad.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end mt-12">
                  <Button
                    onClick={() => onOpenChange(false)}
                    className="bg-primary hover:bg-primary/90 text-white text-lg px-8 py-6"
                  >
                    Cerrar
                  </Button>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
};

export default BlogPostDialog;
