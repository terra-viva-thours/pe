
import React from "react";
import { motion } from "framer-motion";
import { Plus, Minus } from "lucide-react";
import { useState } from "react";

const FAQItem = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="border-b border-gray-200 last:border-0"
    >
      <button
        className="w-full py-6 flex items-center justify-between text-left"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="text-lg font-semibold text-gray-900">{question}</span>
        {isOpen ? (
          <Minus className="w-5 h-5 text-primary flex-shrink-0" />
        ) : (
          <Plus className="w-5 h-5 text-primary flex-shrink-0" />
        )}
      </button>
      <motion.div
        initial={false}
        animate={{
          height: isOpen ? "auto" : 0,
          opacity: isOpen ? 1 : 0,
          marginBottom: isOpen ? "1.5rem" : 0
        }}
        transition={{ duration: 0.3 }}
        className="overflow-hidden"
      >
        <p className="text-gray-600 leading-relaxed">{answer}</p>
      </motion.div>
    </motion.div>
  );
};

const FAQSection = () => {
  const faqs = [
    {
      question: "¿Qué incluye el paquete turístico?",
      answer: "Nuestros paquetes incluyen alojamiento, traslados, tours guiados, algunas comidas y entradas a las atracciones. Cada paquete está diseñado para brindarte una experiencia completa y sin preocupaciones."
    },
    {
      question: "¿Cómo puedo realizar una reserva?",
      answer: "Puedes realizar tu reserva con un 20% de adelanto mediante transferencia bancaria (BCP, Interbank) o Yape. El saldo restante se paga a tu llegada a Tarapoto."
    },
    {
      question: "¿Qué documentos necesito para viajar?",
      answer: "Para viajes nacionales, necesitas tu DNI vigente. Para extranjeros, pasaporte o carné de extranjería válido. Recomendamos tener a mano el comprobante de tu reserva."
    },
    {
      question: "¿Los tours son privados o grupales?",
      answer: "Nuestros tours son en servicio compartido con más personas, lo que permite una experiencia más enriquecedora y precios más accesibles. También ofrecemos opciones privadas bajo solicitud."
    },
    {
      question: "¿Qué pasa si hay mal tiempo?",
      answer: "La seguridad es nuestra prioridad. En caso de condiciones climáticas adversas, podemos modificar o reprogramar las actividades, siempre garantizando tu seguridad y la mejor experiencia posible."
    },
    {
      question: "¿Tienen políticas especiales para niños?",
      answer: "Sí, los menores de 4 años no pagan pasajes ni hotel, pero no tienen beneficio de comida. Los mayores de 5 años pagan pasajes y tienen todos los beneficios completos."
    }
  ];

  return (
    <section className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-bold text-primary mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
            Preguntas Frecuentes
          </h2>
          <p className="text-xl text-gray-600">
            Todo lo que necesitas saber sobre nuestros servicios
          </p>
        </motion.div>

        <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-xl p-8">
          {faqs.map((faq, index) => (
            <FAQItem key={index} {...faq} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
