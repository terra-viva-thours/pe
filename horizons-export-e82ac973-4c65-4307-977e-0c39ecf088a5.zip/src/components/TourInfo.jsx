
import React from "react";
import { CheckCircle2, Clock, MapPin, AlertCircle } from "lucide-react";

const TourInfo = ({ tour }) => {
  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-primary/20 mb-8">
      <h3 className="text-2xl font-bold text-primary mb-4">{tour.name}</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <div>
            <h4 className="font-bold text-lg text-primary mb-3">Incluye</h4>
            <ul className="space-y-2">
              {tour.includes.map((item, index) => (
                <li key={index} className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <h4 className="font-bold text-lg text-primary mb-3">Itinerario</h4>
            <ul className="space-y-2">
              {tour.itinerary.map((item, index) => (
                <li key={index} className="flex items-start gap-2">
                  <Clock className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="mt-6">
        <h4 className="font-bold text-lg text-primary mb-3">Recomendaciones</h4>
        <ul className="space-y-2">
          {tour.recommendations.map((item, index) => (
            <li key={index} className="flex items-start gap-2">
              <AlertCircle className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default TourInfo;
