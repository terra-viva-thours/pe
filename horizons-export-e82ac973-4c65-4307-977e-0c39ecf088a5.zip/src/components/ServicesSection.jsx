
import React from "react";
import { motion } from "framer-motion";
import { Compass, Hotel, Bus, Camera, Coffee, Map, Shield, HeartHandshake } from "lucide-react";

const ServiceCard = ({ icon: Icon, title, description }) => {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
    >
      <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mb-4">
        <Icon className="w-8 h-8 text-primary" />
      </div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </motion.div>
  );
};

const ServicesSection = () => {
  const services = [
    {
      icon: Hotel,
      title: "Alojamiento Premium",
      description: "Hoteles cuidadosamente seleccionados para garantizar tu comodidad y descanso."
    },
    {
      icon: Compass,
      title: "Tours Guiados",
      description: "Excursiones a los principales atractivos turísticos con guías expertos."
    },
    {
      icon: Bus,
      title: "Transporte Privado",
      description: "Vehículos modernos con aire acondicionado y conductores profesionales."
    },
    {
      icon: Camera,
      title: "Fotografía Profesional",
      description: "Servicio opcional de fotografía para inmortalizar tus momentos especiales."
    },
    {
      icon: Coffee,
      title: "Gastronomía Local",
      description: "Degustación de platos típicos y experiencias culinarias únicas."
    },
    {
      icon: Map,
      title: "Rutas Personalizadas",
      description: "Itinerarios adaptados a tus preferencias y tiempo disponible."
    },
    {
      icon: Shield,
      title: "Seguridad Garantizada",
      description: "Protocolos de seguridad y seguros de viaje para tu tranquilidad."
    },
    {
      icon: HeartHandshake,
      title: "Atención 24/7",
      description: "Soporte y asistencia disponible durante toda tu estadía."
    }
  ];

  return (
    <section className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-bold text-primary mb-4">
            Nuestros Servicios
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ofrecemos una amplia gama de servicios diseñados para hacer de tu viaje una experiencia inolvidable
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <ServiceCard {...service} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
