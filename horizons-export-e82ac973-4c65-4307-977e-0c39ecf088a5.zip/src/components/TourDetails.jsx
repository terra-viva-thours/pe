
import React from "react";
import { Clock, MapPin, CheckCircle2 } from "lucide-react";

const TourDetails = ({ tour }) => {
  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-primary/20 mb-8">
      <h3 className="text-2xl font-bold text-primary mb-4">{tour.name}</h3>
      
      <div className="space-y-6">
        <div>
          <h4 className="font-bold text-lg text-primary mb-3">INCLUYE</h4>
          <ul className="space-y-2">
            {tour.includes.map((item, index) => (
              <li key={index} className="flex items-start gap-2">
                <CheckCircle2 className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-lg text-primary mb-3">ITINERARIO</h4>
          <ul className="space-y-2">
            {tour.itinerary.map((item, index) => (
              <li key={index} className="flex items-start gap-2">
                <Clock className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {tour.recommendations && (
          <div>
            <h4 className="font-bold text-lg text-primary mb-3">RECOMENDAMOS</h4>
            <ul className="space-y-2">
              {tour.recommendations.map((item, index) => (
                <li key={index} className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {tour.description && (
          <div>
            <h4 className="font-bold text-lg text-primary mb-3">DESCRIPCIÓN</h4>
            <p className="text-gray-700">{tour.description}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TourDetails;
