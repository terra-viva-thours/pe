
import React from "react";
import { motion } from "framer-motion";
import { Heart, Users, Globe, Award } from "lucide-react";

const AboutUsSection = () => {
  return (
    <div className="bg-white py-24">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-bold text-primary mb-4">
            Sobre Nosotros
          </h2>
          <p className="text-xl text-gray-600">
            Creando experiencias inolvidables desde 2010
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <img 
              className="rounded-2xl shadow-2xl w-full h-[600px] object-cover"
              alt="Equipo Terra Viva Tours"
             src="https://images.unsplash.com/photo-1688916929117-f6d5e9b90f16" />
            <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-2xl shadow-xl">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary">15+</div>
                  <div className="text-sm text-gray-600">Años de<br />Experiencia</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary">10k+</div>
                  <div className="text-sm text-gray-600">Clientes<br />Satisfechos</div>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <h3 className="text-2xl font-bold text-primary mb-4">
                Nuestra Historia
              </h3>
              <p className="text-gray-600 leading-relaxed">
                Terra Viva Tours nació de la pasión por mostrar las maravillas naturales y culturales de Tarapoto. Con más de 15 años de experiencia, nos hemos convertido en líderes en turismo sostenible y aventuras memorables.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="p-6 bg-primary/5 rounded-2xl">
                <Heart className="w-8 h-8 text-primary mb-4" />
                <h4 className="text-lg font-bold mb-2">Pasión</h4>
                <p className="text-gray-600">Amamos lo que hacemos y lo transmitimos en cada experiencia.</p>
              </div>
              <div className="p-6 bg-primary/5 rounded-2xl">
                <Users className="w-8 h-8 text-primary mb-4" />
                <h4 className="text-lg font-bold mb-2">Equipo</h4>
                <p className="text-gray-600">Guías expertos y personal dedicado a tu satisfacción.</p>
              </div>
              <div className="p-6 bg-primary/5 rounded-2xl">
                <Globe className="w-8 h-8 text-primary mb-4" />
                <h4 className="text-lg font-bold mb-2">Sostenibilidad</h4>
                <p className="text-gray-600">Comprometidos con el turismo responsable y ecológico.</p>
              </div>
              <div className="p-6 bg-primary/5 rounded-2xl">
                <Award className="w-8 h-8 text-primary mb-4" />
                <h4 className="text-lg font-bold mb-2">Calidad</h4>
                <p className="text-gray-600">Servicios de primera clase y atención personalizada.</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default AboutUsSection;
