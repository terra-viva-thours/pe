
import React, { useState } from "react";
import { motion } from "framer-motion";
import BlogCard from "@/components/BlogCard";
import BlogPostDialog from "@/components/BlogPostDialog";

const blogPosts = [
  {
    id: 1,
    title: "Hotel Nilas: Lujo y Confort en Tarapoto",
    excerpt: "Descubre por qué el Hotel Nilas es considerado uno de los mejores alojamientos en Tarapoto, combinando comodidad moderna con hospitalidad local.",
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945",
    date: "25 Abril 2025",
    author: "María Torres",
    content: "Contenido completo del artículo..."
  },
  {
    id: 2,
    title: "Guía Completa: Cascadas de Tarapoto",
    excerpt: "Explora las majestuosas cascadas de la región, incluyendo Ahuashiyacu y Pishurayacu. Una guía detallada para tu próxima aventura.",
    image: "https://images.unsplash.com/photo-1434725039720-aaad6dd32dfe",
    date: "24 Abril 2025",
    author: "Juan Pérez",
    content: "Contenido completo del artículo..."
  },
  {
    id: 3,
    title: "Laguna Azul: El Paraíso Escondido",
    excerpt: "Todo lo que necesitas saber sobre la Laguna Azul, una de las joyas turísticas más impresionantes de San Martín.",
    image: "https://images.unsplash.com/photo-1501785888041-af3ef285b470",
    date: "23 Abril 2025",
    author: "Carlos Ruiz",
    content: "Contenido completo del artículo..."
  },
  {
    id: 4,
    title: "Gastronomía Tarapotina: Sabores Únicos",
    excerpt: "Un recorrido por los platos típicos y restaurantes más destacados de Tarapoto. Descubre los sabores que no te puedes perder.",
    image: "https://images.unsplash.com/photo-1540189549336-e6e99c3679fe",
    date: "22 Abril 2025",
    author: "Ana López",
    content: "Contenido completo del artículo..."
  }
];

const BlogSection = () => {
  const [selectedPost, setSelectedPost] = useState(null);
  const [isPostDialogOpen, setIsPostDialogOpen] = useState(false);

  const handleReadMore = (post) => {
    setSelectedPost(post);
    setIsPostDialogOpen(true);
  };

  return (
    <>
      <div className="bg-gradient-to-b from-gray-50 to-white py-24">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-bold text-primary mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
              Blog de Viajes
            </h2>
            <p className="text-xl text-gray-600">
              Descubre historias, consejos y experiencias únicas
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {blogPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <BlogCard
                  post={post}
                  onReadMore={handleReadMore}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      <BlogPostDialog
        post={selectedPost}
        open={isPostDialogOpen}
        onOpenChange={setIsPostDialogOpen}
      />
    </>
  );
};

export default BlogSection;
