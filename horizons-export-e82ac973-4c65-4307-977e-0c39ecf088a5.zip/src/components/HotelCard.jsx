
import React from "react";
import { motion } from "framer-motion";
import { Star, Users, Coffee, Wifi, MapPin, Clock, MapPinned } from "lucide-react";
import { Button } from "@/components/ui/button";

const HotelCard = ({ hotel, onSelect }) => {
  // Tasa de cambio fija (1 USD = 3.85 PEN aproximadamente)
  const priceInUsd = (hotel.priceInPen / 3.85).toFixed(2);

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="bg-white rounded-xl overflow-hidden shadow-lg relative"
    >
      <div className="relative">
        <img 
          alt={`${hotel.name} - Vista exterior`}
          className="w-full h-48 object-cover"
          src={hotel.image} />
        <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm px-3 py-2 rounded-xl">
          <div className="price-tag">
            <div className="price-pen font-bold text-lg">S/ {hotel.priceInPen.toFixed(2)}</div>
            <div className="price-usd text-sm">$ {priceInUsd}</div>
            <div className="text-xs text-gray-600">(inc. IGV)</div>
          </div>
        </div>
        <div className="absolute top-2 left-2 bg-primary text-white px-3 py-1 rounded-xl flex items-center gap-1">
          <MapPinned className="w-4 h-4" />
          <span className="text-sm font-medium">Tarapoto</span>
        </div>
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-primary">{hotel.name}</h3>
          <div className="flex items-center">
            <Star className="w-4 h-4 text-secondary fill-current" />
            <span className="ml-1 text-sm">{hotel.rating}</span>
          </div>
        </div>
        
        <div className="flex items-center text-gray-600 text-sm mb-3">
          <MapPin className="w-4 h-4 mr-1" />
          <span>{hotel.location}</span>
        </div>

        <p className="text-gray-600 text-sm mb-4">{hotel.description}</p>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {hotel.features.map((feature, index) => (
            <span 
              key={index}
              className="text-xs bg-primary/5 text-primary px-2 py-1 rounded-full"
            >
              {feature}
            </span>
          ))}
        </div>

        <Button
          onClick={() => onSelect(hotel)}
          className="w-full bg-primary hover:bg-primary/90 text-white"
        >
          Ver Paquete
        </Button>
      </div>
    </motion.div>
  );
};

export default HotelCard;
