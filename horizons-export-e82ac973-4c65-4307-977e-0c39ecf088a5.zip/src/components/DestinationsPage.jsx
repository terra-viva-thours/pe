
import React from "react";
import { motion } from "framer-motion";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CheckCircle2, MapPin, Calendar, Users, Coffee, Phone, MessageSquarePlus as WhatsappIcon } from 'lucide-react';
import { Button } from "@/components/ui/button";

const DestinationsPage = ({ open, onOpenChange }) => {
  const handleWhatsAppClick = () => {
    window.open('https://wa.me/51984333493', '_blank');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[95%] md:max-w-[90%] lg:max-w-[80%] xl:max-w-7xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-3xl font-bold text-primary text-center mb-6">
            Nuestros Paquetes Turísticos
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-8">
          {/* Información de Reserva */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-2xl font-bold text-primary mb-4">¿Cómo Reservar?</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-primary/10 p-2 rounded-full">
                  <CheckCircle2 className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h4 className="font-bold text-lg">1. Selecciona tu Paquete</h4>
                  <p className="text-gray-600">Elige entre nuestros paquetes de 3 días/2 noches o 6 días/5 noches.</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-primary/10 p-2 rounded-full">
                  <Calendar className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h4 className="font-bold text-lg">2. Elige tus Fechas</h4>
                  <p className="text-gray-600">Selecciona las fechas que mejor se adapten a tu itinerario.</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-primary/10 p-2 rounded-full">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h4 className="font-bold text-lg">3. Número de Viajeros</h4>
                  <p className="text-gray-600">Indica cuántas personas viajarán (mínimo 2 personas).</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-primary/10 p-2 rounded-full">
                  <Phone className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h4 className="font-bold text-lg">4. Realiza tu Reserva</h4>
                  <p className="text-gray-600">Paga el 20% de adelanto vía WhatsApp o con tarjeta/Yape.</p>
                </div>
              </div>
            </div>

            <div className="mt-6">
              <Button
                onClick={handleWhatsAppClick}
                className="w-full bg-primary hover:bg-primary/90 text-white py-6 text-lg"
              >
                Contactar por WhatsApp
              </Button>
            </div>
          </div>

          {/* Información de Paquetes */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="bg-white rounded-xl p-6 shadow-lg"
            >
              <h3 className="text-2xl font-bold text-primary mb-4">Paquete 6 Días / 5 Noches</h3>
              <div className="space-y-3">
                <p className="text-gray-600">Incluye:</p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>5 noches de alojamiento</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>6 tours completos</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>4 almuerzos y 5 desayunos</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>Traslados y guía turístico</span>
                  </li>
                </ul>
              </div>
            </motion.div>

            <motion.div 
              whileHover={{ scale: 1.02 }}
              className="bg-white rounded-xl p-6 shadow-lg"
            >
              <h3 className="text-2xl font-bold text-primary mb-4">Paquete 3 Días / 2 Noches</h3>
              <div className="space-y-3">
                <p className="text-gray-600">Incluye:</p>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>2 noches de alojamiento</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>3 tours completos</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>1 almuerzo y 2 desayunos</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span>Traslados y guía turístico</span>
                  </li>
                </ul>
              </div>
            </motion.div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DestinationsPage;
