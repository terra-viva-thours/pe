
import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { MapPin, Clock, CheckCircle2 } from "lucide-react";
import HotelCard from "@/components/HotelCard";
import PackageDetails from "@/components/PackageDetails";

const hotels = [
  {
    id: 1,
    name: "HOTEL NILAS",
    description: "Desayuno continental, aire A., WiFi, piscina, TV cable, cochera, restaurante y recojo Aeropuerto - Hotel - Aeropuerto",
    location: "Céntrico",
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945",
    priceInPen: 899,
    rating: 4.8,
    capacity: 2,
    breakfast: true,
    wifi: true,
    features: [
      "Aire acondicionado",
      "Piscina",
      "TV cable",
      "Cochera",
      "Restaurante",
      "Traslados aeropuerto"
    ]
  },
  {
    id: 2,
    name: "HOTEL CERRO VERDE",
    description: "Desayuno incluido, aire A., WiFi, TV cable, piscina, cochera y recojo Aeropuerto - Hotel - Aeropuerto",
    location: "A 5 minutos de la plaza de Tarapoto",
    image: "https://images.unsplash.com/photo-1582719508461-905c673771fd",
    priceInPen: 719,
    rating: 4.7,
    capacity: 2,
    breakfast: true,
    wifi: true,
    features: [
      "Aire acondicionado",
      "Piscina",
      "TV cable",
      "Cochera",
      "Traslados aeropuerto"
    ]
  },
  {
    id: 3,
    name: "SAN MARINO",
    description: "Desayuno continental, aire A., WiFi, TV cable, piscina, restaurante y recojo Aeropuerto - Hotel - Aeropuerto",
    location: "A 10 minutos del centro de la ciudad",
    image: "https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9",
    priceInPen: 730,
    rating: 4.6,
    capacity: 2,
    breakfast: true,
    wifi: true,
    features: [
      "Aire acondicionado",
      "Piscina",
      "TV cable",
      "Restaurante",
      "Traslados aeropuerto"
    ]
  },
  {
    id: 4,
    name: "HOTEL RIO CUMBAZA",
    description: "Desayuno continental, Piscina, Aire acondicionado, Wi fi, TV cable y 1 recojo aeropuerto hotel",
    location: "A 5 minutos del centro de la ciudad",
    image: "https://images.unsplash.com/photo-1584132967334-10e028bd69f7",
    priceInPen: 959,
    rating: 4.8,
    capacity: 2,
    breakfast: true,
    wifi: true,
    features: [
      "Aire acondicionado",
      "Piscina",
      "TV cable",
      "Traslados aeropuerto"
    ]
  },
  {
    id: 5,
    name: "MADERA LABRADA LODGE",
    description: "Desayuno continental, ventilador, WiFi, TV cable, piscina, cuenta con áreas verdes y 1 recojo de llegada o de retorno",
    location: "A 8 minutos del centro de la ciudad",
    image: "https://images.unsplash.com/photo-1610641818989-c2051b5e2cfd",
    priceInPen: 899,
    rating: 4.7,
    capacity: 2,
    breakfast: true,
    wifi: true,
    features: [
      "Ventilador",
      "Piscina",
      "TV cable",
      "Áreas verdes",
      "Traslados aeropuerto"
    ]
  },
  {
    id: 6,
    name: "POSADA LODGE",
    description: "Desayuno continental, Aire acondicionado, WiFi, piscina, TV cable, cuenta con áreas verdes y 1 recojo aeropuerto - hotel",
    location: "A 10 minutos del centro de la ciudad",
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945",
    priceInPen: 659,
    rating: 4.6,
    capacity: 2,
    breakfast: true,
    wifi: true,
    features: [
      "Aire acondicionado",
      "Piscina",
      "TV cable",
      "Áreas verdes",
      "Traslados aeropuerto"
    ]
  },
  {
    id: 7,
    name: "CUMBAZA HOTEL Y CONVENCIONES",
    description: "Desayuno Continental, aire A., Wi fi, Piscina, TV cable, Restaurante y recojo Aeropuerto-Hotel",
    location: "A 5 minutos del centro de la ciudad",
    image: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa",
    priceInPen: 959,
    rating: 4.9,
    capacity: 2,
    breakfast: true,
    wifi: true,
    features: [
      "Aire acondicionado",
      "Piscina",
      "TV cable",
      "Restaurante",
      "Traslados aeropuerto"
    ]
  },
  {
    id: 8,
    name: "HOTEL PATARASHCA",
    description: "Desayuno, Wi fi, Piscina, TV cable, Agua fria y caliente y recojo Aeropuerto-Hotel",
    location: "Céntrico",
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945",
    priceInPen: 929,
    rating: 4.7,
    capacity: 2,
    breakfast: true,
    wifi: true,
    features: [
      "Piscina",
      "TV cable",
      "Agua fría y caliente",
      "Traslados aeropuerto"
    ]
  },
  {
    id: 9,
    name: "DM HOTELES",
    description: "Desayuno Continental, aire A., Wi fi, Piscina, TV cable, Restaurante y recojo Aeropuerto-Hotel",
    location: "A 10 minutos del centro de la ciudad",
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945",
    priceInPen: 1590,
    rating: 4.9,
    capacity: 2,
    breakfast: true,
    wifi: true,
    features: [
      "Aire acondicionado",
      "Piscina",
      "TV cable",
      "Restaurante",
      "Traslados aeropuerto"
    ]
  }
];

const SearchDialog = ({ open, onOpenChange, onSelect }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedType, setSelectedType] = useState("all");
  const [selectedHotel, setSelectedHotel] = useState(null);
  const [showPackageDetails, setShowPackageDetails] = useState(false);

  const filteredHotels = hotels.filter(hotel => 
    hotel.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
    (selectedType === "all" || hotel.type === selectedType)
  );

  const handleHotelSelect = (hotel) => {
    setSelectedHotel(hotel);
    setShowPackageDetails(true);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[95%] md:max-w-[90%] lg:max-w-[80%] xl:max-w-7xl max-h-[90vh] overflow-y-auto p-4 md:p-6">
          <DialogHeader className="space-y-4">
            <DialogTitle className="text-2xl md:text-3xl font-bold text-primary text-center">
              Hoteles y Experiencias Disponibles
            </DialogTitle>
            <div className="flex flex-col sm:flex-row gap-3 w-full">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="Buscar hoteles..."
                  className="w-full p-3 border rounded-xl bg-white/50 backdrop-blur-sm 
                           focus:outline-none focus:ring-2 focus:ring-primary/20 
                           transition-all duration-300 placeholder-gray-400"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <select
                className="p-3 border rounded-xl bg-white/50 backdrop-blur-sm 
                         focus:outline-none focus:ring-2 focus:ring-primary/20 
                         transition-all duration-300 cursor-pointer"
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
              >
                <option value="all">Todos los tipos</option>
                <option value="centrico">Céntrico</option>
                <option value="cercano">Cercano al centro</option>
              </select>
            </div>
          </DialogHeader>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {filteredHotels.map(hotel => (
              <HotelCard
                key={hotel.id}
                hotel={hotel}
                onSelect={handleHotelSelect}
              />
            ))}
          </div>
        </DialogContent>
      </Dialog>

      <PackageDetails
        hotel={selectedHotel}
        open={showPackageDetails}
        onOpenChange={setShowPackageDetails}
      />
    </>
  );
};

export default SearchDialog;
