
import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertCircle } from "lucide-react";

const TermsDialog = ({ open, onOpenChange }) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[95%] md:max-w-[90%] lg:max-w-[80%] xl:max-w-7xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-3xl font-bold text-primary text-center mb-6 flex items-center justify-center gap-2">
            <AlertCircle className="w-8 h-8" />
            Términos y Condiciones
          </DialogTitle>
        </DialogHeader>
        
        <div className="bg-white rounded-xl p-6">
          <ul className="space-y-4 text-base">
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">1.</span>
              <p>LAS RESERVAS DEL PAQUETE TURISTICO SON EL 20% PAGO MEDIANTE TRASNFERENCIA (BCP, INTERBANK) YAPE.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">2.</span>
              <p>EL CLIENTE TENDRA QUE ENVIAR UNA CONSTANCIA DEL PAGO, DATOS COMPLETOS (NOMBRE, FECHAS, HOTEL ELEGIDO, TIPO DE HABITACION, NUMERO DE PERSONAS, AEROLINEA Y NUMERO DE VUELO) AL MEDIO POR EL CUAL ESTA CONCRETANDO LA COMPRA (WHATSAP 978 459 506)</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">3.</span>
              <p>EL SALDO RESTANTE DEL 80% SE CANCELARÁ A SU LLEGADA A TARAPOTO EN SU PRIMER TOURS LAMAS O MÁXIMO EN SU TOUR DE LAGUNA AZUL O CASO CONTRARIO EN OFICINA UBICADA EN JR. TUPACAMARU 173-TARAPOTO PARA SOLICITAR SU BOLETA O FACTURA O TAMBIÉN LO PUEDE SOLICITAR POR EL MEDIO QUE REALIZO SU RESERVA.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">4.</span>
              <p>LAS TARIFAS ESTARAN VIGENTES TODO EL AÑO 2024 EXEPTO SEMANA SANTA, FIESTAS PATRIAS, FERIADOS LARGOS Y FIESTAS DE FIN DE AÑO.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">5.</span>
              <p>LOS ASIENTOS NO SE RESERVAN, SON DESTINADOS DE ACUERDO AL ORDEN DE RECOJO SEGÚN HOTELES.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">6.</span>
              <p>TODA RESERVA REALIZADA POR CUALQUIERA DE NUESTROS SERVICIOS NO SE REALIZRA NINGUN TIPO DE DEVOLUCION SI EL CLIENTE DESIDE YA NO PARTICIPAR DEL PROGRAMA.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">7.</span>
              <p>NO SE REALIZARÁ NINGUN TIPO DE REEMBOLSO POR SERVICIO NO UTILIZADOS DE MANERA VOLUNTARIA, ENFERMEDAD U OTROS MOTIVOS SOLO SE PODRA REAZALIZAR UNA REPROGRAMACION SIEMPRE Y CUANDO SE AVISE CON UN MES DE ANTICIPACION.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">8.</span>
              <p>MENORES DE 4 AÑOS NO PAGAN PASAJES, HOTEL, PERO NO TIENEN BENEFICIO DE COMIDA. MAYORES DE 5 AÑOS PAGAN PASAJES Y TIENEN TODOS LOS BENEFICIOS COMPLETOS.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">9.</span>
              <p>TODOS LOS SERVICIOS ESTAN SUGETOS A VARIACION SIN PREVIO AVISO POR CUESTIONES CLIMATOLOGICAS, HUELGAS Y OTROS ACONTECIMIENTOS QUE ESCAPAN DE NUESTRAS MANOS.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">10.</span>
              <p>EL PRECIO DE NUESTROS PAQUETES SON EN SERVICIO COMPARTIDO CON MAS PERSONAS.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">11.</span>
              <p>EL ITINERARIO Y HORARIOS PUEDEN VARIAR A CRITERIO DEL OPERADOR EN CORIDNACION CON EL TURISTA, SIEMPRE GARANTIZANDO LA SEGURIDAD E INTEGRIDAD DEL VIAJERO Y EL MEJOR DESARROLLO DEL SERVICIO OFRECIDO.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">12.</span>
              <p>LOS RECOJO TIENEN UN PROMEDIO DE 30 MINUTOS EN CORDINACION CON EL GUIA LO CUAL EXIGIMOS PUNTUALIDAD EN EL LAPSO DE RECOJO CASO CONTRARIO SOLO ESPERAREMOS 10 MINUTOS SIN DERECHO A REEMBOLSO NI CAMBIO DE ITINERARIO.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">13.</span>
              <p>SE DEBERA RESPETAR EL HORARIO HOTELERO DE CHECK KING Y CHECK OUT. PASADO EL HORARIO HOTELERO SE COBRARÁ LA LEY CHECK OUT EN EL HOTEL.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">14.</span>
              <p>EN CASO DE DISCRIMACION O COMPORTAMIENTOS ENADECUADO, PROCEDEREMOS A CANCELAR LOS SERVICIOS SIN DERECHO A REEMBOLSO.</p>
            </li>
            <li className="flex items-start gap-3">
              <span className="font-bold min-w-[25px]">15.</span>
              <p>SI DESIDE RETIRARSE ANTES DE FINALIZAR EL SERVICIO TAMPOCO HABRA DESCUENTO O CASO ALGUNO DEVOLUCION</p>
            </li>
          </ul>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TermsDialog;
