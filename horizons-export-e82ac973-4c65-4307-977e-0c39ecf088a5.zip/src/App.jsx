
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/components/ui/use-toast";
import { Hotel, Mountain, Leaf, Sun, Compass, Facebook, Instagram, Twitter, Mail, Phone, MessageSquarePlus as WhatsappIcon, Menu, User } from 'lucide-react';
import SearchDialog from "@/components/SearchDialog";
import DestinationsPage from "@/components/DestinationsPage";
import FAQSection from "@/components/FAQSection";
import BlogSection from "@/components/BlogSection";
import AboutUsSection from "@/components/AboutUsSection";
import { AuthDialog } from "@/components/AuthDialog";
import { useAuth } from "@/lib/auth";

function App() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isDestinationsOpen, setIsDestinationsOpen] = useState(false);
  const [selectedHotel, setSelectedHotel] = useState(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState("login");

  const handleSearch = () => {
    setIsSearchOpen(true);
  };

  const handleDestinationsClick = () => {
    setIsDestinationsOpen(true);
  };

  const handleHotelSelect = (hotel) => {
    setSelectedHotel(hotel);
    toast({
      title: "Hotel seleccionado",
      description: `Has seleccionado ${hotel.name}. ¡Excelente elección!`,
    });
  };

  const handleWhatsAppClick = () => {
    window.open('https://wa.me/51984333493', '_blank');
  };

  const handleAuthClick = (mode) => {
    setAuthMode(mode);
    setIsAuthOpen(true);
  };

  return (
    <>
      <div className="min-h-screen bg-background eco-pattern">
        <Toaster />
        <SearchDialog 
          open={isSearchOpen} 
          onOpenChange={setIsSearchOpen}
          onSelect={handleHotelSelect}
        />
        
        <DestinationsPage
          open={isDestinationsOpen}
          onOpenChange={setIsDestinationsOpen}
        />

        <AuthDialog
          open={isAuthOpen}
          onOpenChange={setIsAuthOpen}
          mode={authMode}
        />
        
        {/* Navbar */}
        <nav className="bg-white/90 backdrop-blur-md sticky top-0 z-50 border-b">
          <div className="container mx-auto px-4 py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <img 
                  src="https://storage.googleapis.com/hostinger-horizons-assets-prod/e82ac973-4c65-4307-977e-0c39ecf088a5/bcd6afa03483b8f776021ec4b666f932.png" 
                  alt="Terra Viva Tours Logo" 
                  className="h-12"
                />
              </div>
              
              {/* Mobile Navigation */}
              <div className="md:hidden flex items-center gap-2">
                <Button 
                  variant="outline" 
                  className="border-primary text-primary hover:bg-primary hover:text-white"
                  onClick={handleWhatsAppClick}
                >
                  <Phone className="w-4 h-4" />
                  <span className="ml-2">+51 984 333 493</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-primary hover:bg-primary/10"
                  onClick={() => handleAuthClick("login")}
                >
                  <User className="w-5 h-5" />
                </Button>
              </div>

              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center space-x-6">
                <a href="#" className="text-primary hover:text-primary/80 transition">Inicio</a>
                <button 
                  onClick={handleDestinationsClick}
                  className="text-primary hover:text-primary/80 transition flex items-center gap-2"
                >
                  <WhatsappIcon className="w-4 h-4" />
                  Cómo Comprar por WhatsApp
                </button>
                <Button 
                  variant="outline" 
                  className="border-primary text-primary hover:bg-primary hover:text-white flex items-center gap-2"
                  onClick={handleWhatsAppClick}
                >
                  <Phone className="w-4 h-4" />
                  <span>+51 984 333 493</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-primary hover:bg-primary/10"
                  onClick={() => handleAuthClick("login")}
                >
                  <User className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        </nav>

        {/* Rest of the component remains exactly the same */}
        {/* Hero Section */}
        <div className="hero-gradient text-white py-24 px-4 relative overflow-hidden">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.1 }}
            transition={{ duration: 2 }}
            className="absolute inset-0 eco-pattern"
          />
          <div className="container mx-auto relative">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-3xl mx-auto text-center"
            >
              <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
                Viaja. Siente.<br />Vive Tierra Viva.
              </h1>
              <p className="text-xl md:text-2xl mb-12 text-white/90">
                Descubre experiencias únicas en armonía con la naturaleza
              </p>
            </motion.div>

            {/* Search Box */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="glass-card rounded-2xl p-6 max-w-4xl mx-auto"
            >
              <motion.h2 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="text-2xl font-bold text-white text-center mb-6"
              >
                Seleccionar Hotel + Tours
              </motion.h2>
              <div className="flex justify-center">
                <motion.div 
                  onClick={handleSearch}
                  whileHover={{ scale: 1.02 }}
                  className="hotel-selector relative rounded-xl cursor-pointer overflow-hidden group w-full max-w-xl"
                >
                  <div className="flex items-center p-4 space-x-3">
                    <div className="bg-white/20 p-2 rounded-lg group-hover:bg-white/30 transition-colors">
                      <Hotel className="text-white w-6 h-6" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-medium text-white/90 mb-1">Tu Destino</div>
                      <input 
                        readOnly
                        value={selectedHotel ? selectedHotel.name : ""}
                        placeholder="Seleccionar hotel + tours"
                        className="bg-transparent border-none focus:outline-none w-full text-white placeholder-white/70 cursor-pointer font-medium"
                      />
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Features Section */}
        <div className="container mx-auto py-24 px-4">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl font-bold text-center mb-16 text-primary"
          >
            Experiencias Únicas
          </motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <motion.div 
              whileHover={{ scale: 1.05 }}
              className="bg-white p-6 rounded-2xl shadow-lg card-hover"
            >
              <Mountain className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-2xl font-bold mb-2">Aventuras</h3>
              <p className="text-gray-600">
                Explora destinos únicos y vive experiencias inolvidables en la naturaleza.
              </p>
            </motion.div>

            <motion.div 
              whileHover={{ scale: 1.05 }}
              className="bg-white p-6 rounded-2xl shadow-lg card-hover"
            >
              <Leaf className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-2xl font-bold mb-2">Ecoturismo</h3>
              <p className="text-gray-600">
                Viaja de manera sostenible y contribuye a la conservación del medio ambiente.
              </p>
            </motion.div>

            <motion.div 
              whileHover={{ scale: 1.05 }}
              className="bg-white p-6 rounded-2xl shadow-lg card-hover"
            >
              <Sun className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-2xl font-bold mb-2">Experiencias</h3>
              <p className="text-gray-600">
                Actividades únicas diseñadas para conectar con la naturaleza y la cultura local.
              </p>
            </motion.div>

            <motion.div 
              whileHover={{ scale: 1.05 }}
              className="bg-white p-6 rounded-2xl shadow-lg card-hover"
            >
              <Compass className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-2xl font-bold mb-2">Guías Expertos</h3>
              <p className="text-gray-600">
                Acompañamiento profesional para maximizar tu experiencia de viaje.
              </p>
            </motion.div>
          </div>
        </div>

        {/* Blog Section */}
        <BlogSection />

        {/* About Us Section */}
        <AboutUsSection />

        {/* FAQ Section */}
        <FAQSection />

        {/* Footer */}
        <footer className="bg-primary text-white py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
              <div>
                <img 
                  src="https://storage.googleapis.com/hostinger-horizons-assets-prod/e82ac973-4c65-4307-977e-0c39ecf088a5/bcd6afa03483b8f776021ec4b666f932.png" 
                  alt="Terra Viva Tours Logo" 
                  className="h-16 mb-4"
                />
                <p className="text-white/80">
                  Viaja. Siente. Vive Tierra Viva.
                </p>
                <p className="footer-address">
                  Av. Emancipación 343 Int. 160, Cercado de Lima.
                </p>
              </div>
              <div>
                <h4 className="text-xl font-bold mb-4">Destinos</h4>
                <ul className="space-y-2 text-white/80">
                  <li><a href="#" className="hover:text-white transition">Montañas</a></li>
                  <li><a href="#" className="hover:text-white transition">Selvas</a></li>
                  <li><a href="#" className="hover:text-white transition">Playas</a></li>
                  <li><a href="#" className="hover:text-white transition">Desiertos</a></li>
                </ul>
                <div className="mt-6">
                  <img 
                    src="https://storage.googleapis.com/hostinger-horizons-assets-prod/e82ac973-4c65-4307-977e-0c39ecf088a5/d0ef5f71830c85964ec1a832475db196.png"
                    alt="Protégeme - Turismo Responsable"
                    className="h-16 mb-2"
                  />
                  <img 
                    src="https://storage.googleapis.com/hostinger-horizons-assets-prod/e82ac973-4c65-4307-977e-0c39ecf088a5/08b245499d10b38da8737d026b57f151.png"
                    alt="Agencia de Viajes y Turismo Registrada"
                    className="h-16 mb-2"
                  />
                  <img 
                    src="https://storage.googleapis.com/hostinger-horizons-assets-prod/e82ac973-4c65-4307-977e-0c39ecf088a5/8513f4215c97c158586d1d59bd159786.png"
                    alt="Tarapoto Agencia de Turismo"
                    className="h-16"
                  />
                </div>
              </div>
              <div>
                <h4 className="text-xl font-bold mb-4">Acerca de</h4>
                <ul className="space-y-2 text-white/80">
                  <li><a href="#" className="hover:text-white transition">Sobre Nosotros</a></li>
                  <li><a href="#" className="hover:text-white transition">Términos y Condiciones</a></li>
                  <li><a href="#" className="hover:text-white transition">Libro de Reclamaciones</a></li>
                </ul>
              </div>
              <div>
                <h4 className="text-xl font-bold mb-4">Contacto</h4>
                <ul className="space-y-2 text-white/80">
                  <li className="flex items-center">
                    <Mail className="w-5 h-5 mr-2" />
                    <span>info@terraviva.tours</span>
                  </li>
                  <li className="flex items-start">
                    <Phone className="w-5 h-5 mr-2 mt-1 flex-shrink-0" />
                    <div>
                      <div>Tel + WhatsApp:</div>
                      <div>+51 979 353 433</div>
                      <div>+51 984 333 493</div>
                      <div>+51 987 695 148</div>
                    </div>
                  </li>
                </ul>
                <div className="mt-6 flex space-x-4">
                  <a href="#" className="text-white/80 hover:text-white transition">
                    <Facebook className="social-icon" />
                  </a>
                  <a href="#" className="text-white/80 hover:text-white transition">
                    <Instagram className="social-icon" />
                  </a>
                  <a href="#" className="text-white/80 hover:text-white transition">
                    <Twitter className="social-icon" />
                  </a>
                </div>
              </div>
            </div>
            <div className="border-t border-white/20 mt-12 pt-8 text-center text-white/60">
              <p>&copy; 2025 Terra Viva Tours. Todos los derechos reservados.</p>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
}

export default App;
